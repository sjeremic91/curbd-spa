
export const IMAGE_ROOT =  'https://api.curbdapp.com/public/images'
export const GOOGLE_MAP_KEY = 'AIzaSyAvSMb7TLdpqKiYkv4vlZFEznxZcOY7si4'
export const  STRIPE_CLIENT_ID = 'ca_DiEuWG3LP5IskJR5W37loj8WwYbdbSzs'
export const STRIPE_REDIRECT_URI = 'http://dashboard.curbdapp.com/dashboard/trucks'
export const API_URL = 'https://api.curbdapp.com/public/'
